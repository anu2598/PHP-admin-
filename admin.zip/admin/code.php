<?php

session_start();

$connection = mysqli_connect("localhost","root","","adminpanel");

if(isset($_POST['registerbtn']))
{

    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $cpassword = $_POST['confirmpassword'];
    $usertype = $_POST['usertype'];


    if($password === $cpassword)
    {

        $query = "INSERT INTO register (username,email,password,usertype) VALUES ('$username','$email','$password','$usertype')";
        $query_run = mysqli_query($connection, $query);

        if($query_run)
        {
            // echo('Saved');
            $_SESSION['success'] = "Admin Profile Added";
            header('Location: register1.php');
        }
        else
        {
            $_SESSION['status'] = "Admin Profile Not Added";
            header('Location: register1.php');
        }

    }
        else
        {

            $_SESSION['status'] = "Password and Confirm Password Doesnot Match";
            header('Location: register1.php');

        }

    
}




if(isset($_POST['updatebtn']))
{
    $id = $_POST['edit_id'];
    $username = $_POST['edit_username'];
    $email = $_POST['edit_email'];
    $password = $_POST['edit_password'];
    $usertypeupdate =$_POST['update_usertype'];

    $query = "UPDATE register SET username='$username', email='$email', password='$password', usertype='$usertypeupdate' WHERE id='$id' ";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['success'] = "Your Data is Updated";
        header('Location:register1.php');
    }
    else
    {
        $_SESSION['status'] = "Your Data is Not Updated";
        header('Location:register1.php');
    }

}





if(isset($_POST['delete_btn']))
{
    $id = $_POST['delete_id'];


    $query = "DELETE FROM register WHERE id='$id' ";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['success'] = "Your Data is Deleted";
        header('Location:register1.php');
    }
    else
    {
        $_SESSION['status'] = "Your Data is Not Deleted";
        header('Location:register1.php');
    }
}



if(isset($_POST['login_btn']))
    {
        $email_login = $_POST['email']; 
        $password_login = $_POST['password']; 

    
 
    $query = "SELECT * FROM reg WHERE email='$email_login' AND password='$password_login' ";
    $query_run = mysqli_query($connection, $query);

    if(mysqli_fetch_array($query_run))
    {
        $_SESSION['username'] = $email_login;
        header('Location:index.php');
    }
    else
    {
        $_SESSION['status'] = "Email id / password is invalid";
        header('Location:login.php');
    }
}


if(isset($_POST['about_save']))
{
    $title = $_POST['title'];
    $subtitle = $_POST['subtitle'];
    $description = $_POST['description'];
    $links = $_POST['links'];


    $query = "INSERT INTO abouts (title,subtitle,description,links) VALUES ('$title','$subtitle','$description','$links')";
    $query_run = mysqli_query($connection, $query);


    if($query_run)
    {
        $_SESSION['success'] = "About Us Added";
        header('Location: aboutus.php');
    }
    else
    {
        $_SESSION['status'] = "About Us Not Added";
        header('Location:aboutus.php');
    }

}


if(isset($_POST['updatebttn']))
{
    $id = $_POST['edit_id'];
    $title = $_POST['edit_title'];
    $subtitle = $_POST['edit_subtitle'];
    $description = $_POST['edit_description'];
    $links = $_POST['edit_links'];

    $query = "UPDATE abouts SET title='$title', subtitle='$subtitle', description='$description', links='$links' WHERE id='$id' ";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['success'] = "Your Data is Updated";
        header('Location:aboutus.php');
    }
    else
    {
        $_SESSION['status'] = "Your Data is Not Updated";
        header('Location:aboutus.php');
    }

}


if(isset($_POST['delete_btton']))
{
    $id = $_POST['delete_id'];


    $query = "DELETE FROM abouts WHERE id='$id' ";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['success'] = "Your Data is Deleted";
        header('Location:aboutus.php');
    }
    else
    {
        $_SESSION['status'] = "Your Data is Not Deleted";
        header('Location:aboutus.php');
    }
}



if(isset($_POST['reg_btn']))
{
    $firstname_reg = $_POST['firstname']; 
    $lastname_reg = $_POST['lastname']; 
    $email_reg = $_POST['email']; 
    $password_reg = $_POST['password'];
    $passrepeat_reg = $_POST['passrepeat']; 
 

    if($password_reg === $passrepeat_reg)
    {

        $query = "INSERT INTO reg (firstname,lastname,email,password) VALUES ('$firstname_reg','$lastname_reg','$email_reg','$password_reg')";
        $query_run = mysqli_query($connection, $query);

        if($query_run)
        {
            // echo('Saved');
            $_SESSION['success'] = "Account Registered";
            header('Location: register.php');
        }
        else
        {
            $_SESSION['status'] = "Account Not Registered";
            header('Location: register.php');
        }

    }
        else
        {

            $_SESSION['status'] = "Password and Confirm Password Doesnot Match";
            header('Location: register.php');

        }
}



if(isset($_POST['save_faculty']))
{
    $name = $_POST['faculty_name'];
    $design = $_POST['faculty_designation'];
    $descrip = $_POST['faculty_description'];
    $images = $_FILES["faculty_image"]['name'];

    // if(file_exists("upload/" . $_FILES["faculty_image"]["name"]))
    // {
    //    $store = $_FILES["faculty_image"]["name"];
    //    $_SESSION['status'] = "Image already exists. '.$store.'";
    //    header('Location: faculty.php');
    // }
    
    // else
    // {

        $query = "INSERT INTO faculty (name,design,descrip,images) VALUES ('$name','$design','$descrip','$images')";
        $query_run = mysqli_query($connection, $query);


        if($query_run)
        {
            move_uploaded_file($_FILES["faculty_image"]["tmp_name"],"upload/".$_FILES["faculty_image"]["name"]);
            $_SESSION['success'] = "Faculty details are Added";
            header('Location: faculty.php');
        }
        else
        {
            $_SESSION['status'] = "Faculty details are Not Added";
            header('Location: faculty.php');
        }
    }   

// }
// if(isset($_POST['imagebtn']))
// {
//     $name = $_POST['name'];
//     $designation = $_POST['designation'];
//     $description = $_POST['description'];
//     $image= $_FILES["image"]['name'];
//         $query = "INSERT INTO image (name,designation,description,image) VALUES ('$name','$designation','$description','$image')";
//         $query_run = mysqli_query($connection, $query);
    
//         if($query_run)
//         {
        
//             move_uploaded_file($_FILES["image"]["tmp_name"],"upload/".$_FILES["image"]["name"]);
//             $_SESSION['success'] =  "Admin is Added Successfully";
            
//             header('Location: image.php');
//         }
//         else 
//         {
//             echo "not done";
//             $_SESSION['status'] =  "Admin is Not Added";
//             header('Location: image.php');
//         }
//     }






if(isset($_POST['update_btn']))
{
    $id = $_POST['edit_id'];
    $name = $_POST['edit_name'];
    $design = $_POST['edit_designation'];
    $descrip = $_POST['edit_description'];
    $images = $_POST['edit_image'];

    $query = "UPDATE faculty SET name='$name', design='$design', descrip='$descrip', images='$images' WHERE id='$id' ";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['success'] = "Your Data is Updated";
        header('Location:faculty.php');
    }
    else
    {
        $_SESSION['status'] = "Your Data is Not Updated";
        header('Location:faculty.php');
    }

}


if(isset($_POST['delete_bttn']))
{
    $id = $_POST['delete_id'];


    $query = "DELETE FROM faculty WHERE id='$id' ";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['success'] = "Your Data is Deleted";
        header('Location:faculty.php');
    }
    else
    {
        $_SESSION['status'] = "Your Data is Not Deleted";
        header('Location:faculty.php');
    }
}








?>