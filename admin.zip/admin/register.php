<?php 
session_start();

include('includes/header.php');

?>


<div class="container" style="margin-left: 370px";>
<div class="col-xl-8 col-lg-8 col-md-8">
        <div class="card o-hidden border-0 shadow-lg my-5 ">
            <div class="card-body p-0">
                <!-- Nested Row within Card Body -->
                <div class="row">
                   
                    <div class="col-lg-12">
                        <div class="p-5">
                            <div class="text-center">
                                <h1 class="h4 text-gray-900 mb-4">Register</h1>
                            </div>
                            <form class="user" action="code.php" method="POST">


                            <?php

                                                if(isset($_SESSION['success']) && $_SESSION['success'] !='')
                                                {
                                                echo '<h5 class="bg-primary text-white"> '.$_SESSION['success'].' </h5>';
                                                unset($_SESSION['success']);
                                                }

                                                if(isset($_SESSION['status']) && $_SESSION['status'] !='')
                                                {
                                                echo '<h5 class="bg-danger text-white">'.$_SESSION['status'].' </h5>';
                                                unset($_SESSION['status']);
                                                }
                            ?>
                                <div class="form-group row">
                                    <div class="col-sm-12 mb-3 mb-sm-3">
                                        <input type="text" name="firstname" class="form-control form-control-user" pattern="[a-zA-Z ]{1,40}" title="Enter Alphabets Only" placeholder="First Name">
                                    </div>
                                    <div class="col-sm-12 mb-3 mb-sm-0">
                                        <input type="text" name="lastname" class="form-control form-control-user" pattern="[a-zA-Z ]{1,40}" title="Enter Alphabets Only" placeholder="Last Name">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <input type="email" name="email" class="form-control form-control-user" placeholder="Email Address">
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-12 mb-3 mb-sm-3">
                                        <input type="password" name="password" class="form-control form-control-user" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" placeholder="Password">
                                    </div>
                                    <div class="col-sm-12 mb-3 mb-sm-0">
                                        <input type="password" name="passrepeat" class="form-control form-control-user" placeholder="Repeat Password">
                                    </div>
                                </div>
                                <button type="submit" name="reg_btn" class="btn btn-primary btn-user btn-block">
                                    Register Account
                                </button>
                                <hr>
                                <!-- <a href="index.php" class="btn btn-google btn-user btn-block">
                                    <i class="fab fa-google fa-fw"></i> Register with Google
                                </a> -->

                          

                                <!-- <a href="index.html" class="btn btn-facebook btn-user btn-block">
                                    <i class="fab fa-facebook-f fa-fw"></i> Register with Facebook
                                </a>  -->
                            </form>
                            
                            <div class="text-center">
                                <a class="small" href="forgot-password.html">Forgot Password?</a>
                            </div>
                            <div class="text-center">
                                <a class="small" href="login.php">Already have an account? Login!</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>




<?php 
include('includes/script.php');


?>