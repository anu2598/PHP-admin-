<?php

session_start();

$connection = mysqli_connect("localhost","root","","adminpanel");




if(isset($_POST['save_faculty']))
{
    $name = $_POST["faculty_name"];
    $design = $_POST["faculty_designation"];
    $descrip = $_POST["faculty_description"];
    $images = $_FILES["faculty_image"]["name"];

    if(file_exists("upload/" . $_FILES["faculty_image"]["name"]))
    {
       $store = $_FILES["faculty_image"]["name"];
       $_SESSION['status'] = "Image already exists. '.$store.'";
       header('Location: faculty.php');
    }
    
    else
    {

        $query = "INSERT INTO faculty ('name','design','descrip','images') VALUES ('$name','$design','$descrip','$images')";
        $query_run = mysqli_query($connection, $query);


        if($query_run)
        {
            move_uploaded_file($_FILES["faculty_image"]["tmp_name"],"upload/".$_FILES["faculty_image"]["name"]); 
            $_SESSION['success'] = "Faculty details are Added";
            header('Location: faculty.php');
        }
        else
        {
            $_SESSION['status'] = "Faculty details are Not Added";
            header('Location: faculty.php');
        }
    }   

}

?>